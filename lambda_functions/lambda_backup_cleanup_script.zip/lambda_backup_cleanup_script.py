#! python3
__author__ = 'Zachary Hill'

import boto3
import datetime

ec2 = boto3.resource('ec2')
# iam = boto3.resource('iam')


def find_snapshots():
    """Searches for all snapshots which have a tag key of 'delete_on'

    Args:
    none

    returns: dict with snapshots as keys and a dict of tags as values - snapshot: {tags}
    """
    all_snapshots_dict = {}
    snapshot_filters = [{'Name': 'tag-key', 'Values': ['delete_on']}]
    snapshot_iterator = ec2.snapshots.filter(Filters=snapshot_filters)

    for snapshot in snapshot_iterator:
        all_snapshots_dict[snapshot.snapshot_id] = {tag['Key']: tag['Value']for tag in snapshot.tags}

    return all_snapshots_dict


def compare_delete_on(snapshot_dict):
    """Compares current date to date found in the 'delete_on' snapshot tag.

    Args:
    snapshot_dict -- dict with snapshots as keys and a dict of tags as values - snapshot: {tags}

    returns: list with snapshot ids
    """
    snapshot_del_list = []
    delete_prior_to = datetime.date.today().strftime('%Y-%m-%d')

    for snapshot, tags in snapshot_dict.items():
        if tags['delete_on'] <= delete_prior_to:
            print('Snapshot ID: {0} - Delete Date: {1}'.format(snapshot, tags['delete_on']))
            snapshot_del_list.append(snapshot)

    return snapshot_del_list


def delete_snapshots(snapshot_list):
    """Deletes a list of snapshots.

    Args:
    snapshot_list -- list with snapshot ids.

    returns: list with snapshot ids which have been deleted
    """
    deleted_snapshot_ids = []
    for snapshot_id in snapshot_list:
        working_snapshot = ec2.Snapshot(snapshot_id)
        working_snapshot.delete()
        deleted_snapshot_ids.append(snapshot_id)
    return deleted_snapshot_ids


def main():
    # TODO find snapshots in all regions. Currently only searches for source region Lambda is run
    script_boilerplate = '--------------------------------------------------' \
                         '\n          AWS EC2 Backup Cleanup Script' \
                         '\n       Created by Zachary Hill 2017_09_10' \
                         '\n--------------------------------------------------\n'
    # account_id = [iam.CurrentUser().arn.split(':')[4]]
    print('{0}\nFinding snapshots to cleanup...'.format(script_boilerplate))

    # Find all snapshots in the AWS account
    all_snapshots_dict = find_snapshots()

    # Determine which snapshots have passed their retention date and should be deleted
    print('Scanning retention date tags for snapshots which will be deleted...')
    snapshots_to_delete = compare_delete_on(all_snapshots_dict)
    print('Found {0} snapshot(s) to delete.\nSnapshot ID(s) which will be deleted:\n{1}'.format(len(snapshots_to_delete), snapshots_to_delete))

    # Delete the snapshots
    print('Deleting snapshots...')
    delete_snapshots(snapshots_to_delete)
    print('Completed snapshot cleanup!')


def lambda_handler(event, context):
    main()


if __name__ == '__main__':
    main()
