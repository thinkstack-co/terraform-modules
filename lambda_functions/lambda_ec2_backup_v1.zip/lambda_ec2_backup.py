#! python3
__author__ = 'Zachary Hill'

import boto3
import datetime


ec2 = boto3.resource('ec2')


# TODO find all active regions with EC2 instances to iterate over entire script with those different regions
# def aws_regions():
#     """Outputs a list of all usable regions"""
#     regions = ec2.describe_regions().get('Regions',[] )
#     print('Regions are: ', regions)

def find_instances_and_volumes(region):
    """Searches all instances within the region for both the volumes and tags

    Args:
    region -- The AWS region to find instances and volumes in.

    returns: Two dictionaries:
            dict with instances as keys and a list of volumes as values - instance: [volumes]
            dict with instances as keys and a dict of tags as values - instances: {tags}
    """
    instance_volumes_dict = {}
    instance_tags_dict = {}
    instance_iterator = ec2.instances.all()

    for instance in instance_iterator:
        instance_volumes_dict[instance.id] = [vol.id for vol in instance.volumes.all()]
        instance_tags_dict[instance.id] = {tag['Key']: tag['Value']for tag in instance.tags}

    return instance_volumes_dict, instance_tags_dict


def sanitize_tags(tags):
    """Iterates through tags dictionary and sanitizes all entries to be lowercase

    Args:
    tags -- dict with instances as keys and a dict of tags as values - instance: {tags}

    returns: dict with instances as keys and a dict of tags as values - instance: {tags}
    """
    sanitized_dict = {key: {tag.lower(): tag_value.lower() for tag, tag_value in value.items()} for key, value in tags.items()}

    return sanitized_dict


def find_backups(tags):
    """Iterates through tags dictionary to find and output all instances with
    a backup key set to a value of 'true', 'yes', or '1'

    Args:
    tags -- dict with instances as keys and a dict of tags as values - instance: {tags}

    returns: dict with instances as keys and a dict of tags as values - instance: {tags}
    """
    instances_to_backup = {}
    # List of tag values which indicate the instance should be backed up
    backup_tag_values = ['true', 'yes', '1']

    for instance in tags:
        if tags.get(instance).get('backup'):
            if tags[instance]['backup'] in backup_tag_values:
                instances_to_backup[instance] = tags[instance]

    return instances_to_backup


def find_retention_tags(tags):
    """Searches instances which will be backed up for the tag 'retention' and
    it's partnered value.

    Args:
    tags -- dict with instances as keys and dict of tags as values - instance: {tags}

    returns: dict with instances as keys and retention string as the value - instance: 'retention_number'
    """
    instance_retention_dict = {}
    print('{0:^24}|{1:^24}|{2:^24}'.format('Name', 'Instance ID', 'Retention'))
    for instance in tags:
        instance_name = tags.get(instance).get('name')
        per_instance_retention = tags.get(instance).get('retention')

        if per_instance_retention is None:
            per_instance_retention = '7'

        instance_retention_dict[instance] = per_instance_retention
        print('{0:^24}|{1:^24}|{2:^24}'.format(instance_name, instance, per_instance_retention))

    return instance_retention_dict


def trim_volumes(instances, tags):
    """Trims up the volume dictionary to only include volumes which exist in
    the tags dictionary.

    Args:
    instances -- dict with instances as keys and list of volumes as values - instance: [volumes]
    tags -- dict with instances as keys and dict of tags as values - instance: {tags}

    returns: dict with instances as keys and list of volumes as the value - instance: [volumes]
    """
    backup_volumes = {}

    for instance_id in tags:
        if instance_id in instances.keys():
            backup_volumes[instance_id] = instances[instance_id]

    return backup_volumes


def backup_volumes(instances, tags):
    """Initiates a snapshot of all input volumes

    Args:
    instances -- dict with instances as keys and list of volumes as values - instance: [volumes]
    tags -- dict with instances as keys and dict of tags as values - instance: {tags}

    returns: dict with snapshot ids as keys and the instance id as the value - snapshot_id: instance
    """
    snapshots_to_tag = {}

    for instance, volumes in instances.items():
        instance_name = tags.get(instance).get('name')
        print('\nTaking snapshot of {0}\nInstance ID: {1}\nVolume IDs are: {2}'.format(instance_name, instance, volumes))
        for volume in volumes:
            snapshot = ec2.create_snapshot(
                Description='Automated backup script',
                VolumeId=volume
            )
            snapshots_to_tag[snapshot.id] = instance

    print('\nNumber of snapshots taken = {0}\nSnapshot IDs: {1}'.format(len(snapshots_to_tag), snapshots_to_tag))

    return snapshots_to_tag


def set_retention_tags(snapshot_ids, retention, tags):
    """Checks the current date against the retention value in order to set the
    delete_on tag within each volume.

    Args:
    snapshot_ids -- dict with snapshot ids as keys and the instance id as the value - snapshot_id: instance
    retention -- dict with instances as keys and retention string as the value - instance: 'retention_number'
    tags -- dict with instances as keys and a dict of tags as values - instance: {tags}

    returns: str indicating a date in the format of YYYY-MM-DD
    """

    # TODO Create tags for instance ID, and volume ID
    for snapshot_id, instance in snapshot_ids.items():
        current_snapshot = ec2.Snapshot(snapshot_id)
        delete_date = datetime.date.today() + datetime.timedelta(days=int(retention[instance]))
        instance_name = tags.get(instance).get('name')
        tags_for_snapshot = [
            {'Key': 'delete_on', 'Value': str(delete_date)},
            {'Key': 'automated', 'Value': 'yes'},
            {'Key': 'created_by', 'Value': 'lambda'},
            {'Key': 'Name', 'Value': instance_name},
        ]
        current_snapshot.create_tags(Tags=tags_for_snapshot)

    return delete_date


def main():
    script_boilerplate = '--------------------------------------------------' \
                         '\n              AWS EC2 Backup Script' \
                         '\n       Created by Zachary Hill 2017_09_10' \
                         '\n--------------------------------------------------\n'

    print('{0}\nFinding instances to backup...'.format(script_boilerplate))

    # Find all of the instances with volumes
    all_volumes_dict, all_tags_dict = find_instances_and_volumes('us-east-1')
    print('...found all instances, volumes, and tags in ec2 \
        \nTotal number of instances:\n{0}'.format(len(all_volumes_dict)))

    # Sanitize all tags
    sanitized_tags_dict = sanitize_tags(all_tags_dict)
    print('...sanitized all tags to be lowercase')

    # Find all instances with 'backup' tag set to 'true', 'yes', or '1'
    backup_tags_dict = find_backups(sanitized_tags_dict)
    print('Trimming the list of instances with backup parameter set... \
        \nNumber of instances to backup:\n{0}'.format(len(backup_tags_dict)))

    # Determine the retention period per instance
    print('Finding the retention tags...')
    retention_dict = find_retention_tags(backup_tags_dict)

    # Trim the volume dict to only include necessary instances and volumes
    print('Trimming the list of volumes based on instances with backup parameter set...')
    backup_volumes_dict = trim_volumes(all_volumes_dict, backup_tags_dict)

    # Kick off the snapshots and return those snapshot ids
    print('Starting backups...')
    snapshot_id_dict = backup_volumes(backup_volumes_dict, backup_tags_dict)

    # Set the delete_on retention tag
    print('Setting retention tags on snapshot ids created via this script...')
    set_retention_tags(snapshot_id_dict, retention_dict, backup_tags_dict)
    print('Backups completed!')

    # TODO @feature add the ability to email or send to glip any status messages
    # TODO @feature add the ability to log all messages to the logger lambda function


def lambda_handler(event, context):
    main()


if __name__ == '__main__':
    main()
