from setuptools import setup


setup(name='pre-commit-placeholder-package', version='0.0.0')
