"""
Saas provides a set of general saas services.
"""

from diagrams import Node


class _Saas(Node):
    _provider = "saas"
    _icon_dir = "resources/saas"

    fontcolor = "#ffffff"


class Saas(_Saas):
    _icon = "saas.png"
